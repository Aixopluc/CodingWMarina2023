package UF4.HerenciaMultinivell;

public class Arona extends Seat{
    private String color;
    private double km;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getKm() {
        return km;
    }

    public void setKm(double km) {
        this.km = km;
    }

}
