package UF4.HerenciaMultinivell;

public class Seat extends Car{
    private String model;

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void brand(){}
    public void speed(){}

}
