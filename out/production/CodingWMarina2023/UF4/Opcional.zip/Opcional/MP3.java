package UF4.Opcional;

public class MP3 extends Musica{

    private int mode;

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

}
