package UF4.Opcional;

public class OGG extends Musica{

    private int enter;

    public int getEnter() {
        return enter;
    }

    public void setEnter(int enter) {
        this.enter = enter;
    }

}
