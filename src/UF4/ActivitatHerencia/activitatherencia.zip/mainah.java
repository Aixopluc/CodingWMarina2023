package UF4.ActivitatHerencia;

public class mainah {
    Persona p1 = new Persona();
    Estudiant e1 = new Estudiant();
}
